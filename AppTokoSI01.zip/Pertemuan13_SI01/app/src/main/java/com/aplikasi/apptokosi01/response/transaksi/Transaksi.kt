package com.aplikasi.apptokosi01.response.transaksi

data class Transaksi(
    val admin_id: String,
    val id: String,
    val tanggal: String,
    val total: String
)