package com.aplikasi.apptokosi01.response.login

data class Data(
    val admin : Admin,
    val token: String
)
